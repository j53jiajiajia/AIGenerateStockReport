def get_openai():
    return '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'

